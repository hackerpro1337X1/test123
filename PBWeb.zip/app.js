var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');
var auth = require('http-auth');
var ejs = require('ejs');
var jimp = require('jimp');
var bwipjs = require('bwip-js');
var mongoUtil = require('./mongoUtil');

var app = express();

//Admin Auth
var basic = auth.basic({
	realm: 'Admin Area!',
	file: 'users.htpasswd'
});

app.use(auth.connect(basic));

//MongoDB
mongoUtil.connectToServer( function( err ) {
  // start the rest of your app here
} );

//View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Body Parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

// Set Static Path
app.use(express.static(path.join(__dirname, 'public')));

//Route Stuff
app.get('/', function(req, res){
	var db = mongoUtil.getDb();
	db.collection('cards').find({owner: req.user}).toArray(function(err, docs){
		if(!err){
			res.render('index', {user: req.user, cards: docs, json: JSON.stringify(docs)});
		}
	});
});

app.get('/pay', function(req, res){
	if (req.query.code && req.query.id){
		bwipjs.toBuffer({
			bcid:        'ean13',         // Barcode type
			text:        req.query.code,  // Text to encode
			scale:       3,               // 3x scaling factor
			height:      38,              // Bar height, in millimeters
			includetext: true,            // Show human-readable text
			textxalign:  'center',        // Always good to set this
		}, function (err, png) {
			if (!err) {
				jimp.read('./public/img/pay.png', function(err, image){
					if(!err){
						jimp.read(png, function(err, image2){
							if(!err){
								image.composite(image2, 360 - image2.bitmap.width / 2, 480);
								jimp.loadFont(jimp.FONT_SANS_32_WHITE).then(function(font){
									image.print(font, 380, 880, req.query.id);
									image.write('./public/img/pay_tmp.png', function(){
										res.render('pay');
									});
								});
							}else{
								res.send('jimp err');
							}
						});
					}else{
						res.send('jimp err');
					}
				});
			} else {
				res.send('barcode error');
			}
		});
	
	}else{
		res.send('no args');
	}
});

app.get('/print', function(req, res){
	res.render('print');
});

app.post('/add', function(req, res){
	if(req.body.id){
		req.body.owner = req.user;
		if(!isNaN(req.body.points)){
			req.body.points = parseInt(req.body.points);
			var db = mongoUtil.getDb();
			db.collection('cards').insert(req.body, function(err, result){
				if(!err){
					res.send('ok');
				}else{
					res.send('db err');
				}
			});
		}else{
			res.send('points is not a valid number');
		}
	}else{
		res.send('no args');
	}
});

app.get('/add', function(req, res){
	res.render('add', {user: req.user});
});

app.post('/spent', function(req, res){
	if(req.body.id && req.body.points){
		if(!isNaN(req.body.points)){
			var db = mongoUtil.getDb();
			db.collection('cards').update({id: req.body.id, owner: req.user}, {$inc: {points: req.body.points * -1}} , function(err, result){
				if(!err){
					res.send('ok');
				}else{
					res.send('db err');
				}
			});
		}else{
			res.send('points is not a valid number');
		}
	}else{
		res.send('no args');
	}
});

app.post('/notes', function(req, res){
	if(req.body.id && req.body.text){
		var db = mongoUtil.getDb();
		db.collection('cards').update({id: req.body.id, owner: req.user}, {$set: {notes: req.body.text}} , function(err, result){
			if(!err){
				res.send('ok');
			}else{
				res.send('db err');
			}
		});
	}else{
		res.send('no args');
	}
});

app.post('/move', function(req, res){
	if(req.body.id && req.body.newOwner){
		var db = mongoUtil.getDb();
		db.collection('cards').update({id: req.body.id, owner: req.user}, {$set: {owner: req.body.newOwner}} , function(err, result){
			if(!err){
				res.send('ok');
			}else{
				res.send('db err');
			}
		});
	}else{
		res.send('no args');
	}
});

//Run WebServer

var redirectApp = express();

redirectApp.get('/', function(req, res){
	res.redirect('https://pbboys.club');
});

var http = true;
var https = false;

if(http){
	var http = require('http');
	var httpServer = http.createServer(app);
	httpServer.listen(8080);
	console.log("Running HTTP Server on Port: 8080");
}else{
	var http = require('http');
	var httpServer = http.createServer(redirectApp);
	httpServer.listen(8080);
	console.log("Running HTTP Server on Port: 8080");
}

if(https){
	var fs = require('fs');
	var https = require('https');
	var privateKey  = fs.readFileSync('./privkey.pem', 'utf8');
	var certificate = fs.readFileSync('./cert.pem', 'utf8');
	var credentials = {key: privateKey, cert: certificate};
	var httpsServer = https.createServer(credentials, app);
	httpsServer.listen(8443);
	console.log("Running HTTPS Server on Port: 8443");
}
