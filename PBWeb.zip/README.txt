=== 1 ====

Nutzer in users.htpasswd hinzuf�gen
Format: user:pass

=== 2 ===

Wenn ihr HTTPS wollt:
 app.js Zeile 128 -> Domain einf�gen
 app.js Zeile 132 -> var https = true

=== 3 ===

MongoDB installieren

mongo starten
db pbcard ausw�hlen
collection "cards" erstellen

=== 4 ===

NodeJS installieren (neuste! nicht von apt-get)

=== 5 ===

Module installieren

npm install

=== 6 ===

Starten

nodejs app.js