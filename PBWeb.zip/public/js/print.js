function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

$(document).ready(function(){
    if(getParameterByName('data')){
        var box = document.getElementById('box');
        var data = JSON.parse(getParameterByName('data'));
        var codes = data['codes'];
        console.log(data);
        for(var i = 0; i < codes.length; i++){
            var barcode = $(box).append('<img id="barcode' + i +'"></img>');
            try{
                JsBarcode('#barcode' + i)
                    .EAN13(codes[i], {margin: 0, marginTop: 10, marginBottom: 10, width: 1.25, height: 40, fontSize: 18, textMargin: 0})
                    .render();
            }
            catch(err){
                console.log("ERR: " + err);
            }
        }
    }else{
        $('.main').removeAttr('hidden');
    }
    $('#btn').click(function(){
        var codes = [];
        var lines = $('#lines').val().split('\n');
        for(var i = 0; i < lines.length; i++){
            codes.push(lines[i]);
        }
        var data = JSON.stringify(codes);
        window.location.replace('')
    });
});