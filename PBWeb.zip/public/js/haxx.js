var cards;

$(document).ready(function(){
  $("tr").click(function(){

    var id = $(this).eq(0).find("td").eq(2).html();
    var code = "240" + id.replace(/.$/,checkDigit("240" + id));

    var card;
    cards.forEach(function(entry){
      if(entry.id === id){
        card = entry;
      }
    });

    try{
      JsBarcode("#barcode")
        .EAN13(code, {margin: 0, marginTop: 10, marginBottom: 10, width: 3, fontSize: 18, textMargin: 0})
        .render();
    }
    catch(err){
      console.log("ERR: " + err);
    }

    $("#cards").hide("slow");
    $("#card-info").append("<p> Name: " + card.name + "</p>");
    $("#card-info").append("<p> Card ID: " + card.id + "</p>");
    $("#card-info").append("<p> Points: " + card.points + "</p>");
    var notes = $("<textarea></textarea>");
    $(notes).val(card.notes);
    $("#card-info").append(notes);
    var saveNotesBtn = $("<br><button>save</button>");
    $("#card-info").append(saveNotesBtn);
    $("#card-info").append("<p> PIN: " + card.pin + "</p>");
    $("#card-info").append("<p> Password: " + card.password + "</p>");
    var payBtn = $('<button class="payBtn">Pay</button>');
    $("#card-info").append(payBtn);
    var spendBtn = $("<button>Spend</button>");
    $("#card-info").append(spendBtn);
    var moveBtn = $("<button>Move</button>");
    $("#card-info").append(moveBtn);
    var deleteBtn = $("<button>Delte</button>");
    $("#card-info").append(deleteBtn);
    var backBtn = $("<button>Back</button>");
    $("#card-info").append(backBtn);

    $(saveNotesBtn).click(function(){
      if(!$("#cards").is(":visible")){
        $.ajax({
          type: "POST",
          url: "/notes",
          data: "text=" + $(notes).val() + "&id=" + id,
          success: function(){
            swal({
              type: "success",
              title: "Notes saved",
            }).catch(swal.noop);
          }
        });
        card.notes = $(notes).val();
      }
    });

    $(payBtn).click(function(){
      window.open('/pay?code=' + code + '&id=' + id, '_blank');
    });

    $(spendBtn).click(function(){
      if(!$("#cards").is(":visible")){
        swal({
          title: "How much did u spent ?",
          input: "number",
          showCancelButton: true,
          confirmButtonText: "Submit",
          showLoaderOnConfirm: true,
          preConfirm: function (value) {
            return new Promise(function (resolve, reject) {
              $.ajax({
                type: "POST",
                url: "/spent",
                data: "points=" + value + "&id=" + id,
                success: function(){resolve();}
              })
            })
          },
          allowOutsideClick: false
        }).then(function (value) {
          swal({
            type: "success",
            title: "Payment done!",
            html: "You spent: " + value
          }).then(function(){
            location.reload();
          });
        }).catch(swal.noop);
      }
    });

    $(moveBtn).click(function(){
      if(!$("#cards").is(":visible")){
        swal({
          title: "Send Card to ...",
          input: "text",
          showCancelButton: true,
          confirmButtonText: "Submit",
          showLoaderOnConfirm: true,
          preConfirm: function (value) {
            return new Promise(function (resolve, reject) {
              $.ajax({
                type: "POST",
                url: "/move",
                data: "newOwner=" + value + "&id=" + id,
                success: function(){resolve();}
              })
            })
          },
          allowOutsideClick: false
        }).then(function (value) {
          swal({
            type: "success",
            title: "Card moved!",
            html: "New Owner: " + value
          }).then(function(){
            location.reload();
          });
        }).catch(swal.noop);
      }
    });

    $(deleteBtn).click(function(){
      if(!$("#cards").is(":visible")){
        swal({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!',
          showLoaderOnConfirm: true,
          preConfirm: function (value) {
            return new Promise(function (resolve, reject) {
              $.ajax({
                type: "POST",
                url: "/move",
                data: "newOwner=trash&id=" + id,
                success: function(){resolve();}
              })
            })
          },
          allowOutsideClick: false
        }).then(function (value) {
          swal({
            type: "success",
            title: "Card deleted!",
          }).then(function(){
            location.reload();
          });
        }).catch(swal.noop);
      }
    });

    $(backBtn).click(function(){
      $("#cards").show("slowly");
      $("#note").html("Select Card first!");
      $("#barcode").empty();
      $("#card-info").empty();
    });

  });
});

function loadData(data){
  cards = data;
}
