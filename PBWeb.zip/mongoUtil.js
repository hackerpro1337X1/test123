var MongoClient = require( 'mongodb' ).MongoClient;

var _db;

module.exports = {

  connectToServer: function( callback ) {
    MongoClient.connect( "mongodb://localhost:27017/pbcard", function( err, db ) {
      _db = db;
      if(err){
        console.log(err);
      }
      return callback( err );
    } );
  },

  getDb: function() {
    return _db;
  }
};
